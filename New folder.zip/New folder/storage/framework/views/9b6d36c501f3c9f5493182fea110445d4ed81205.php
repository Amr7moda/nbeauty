

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col mt-4">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Order_id</th>
                        <th scope="col">name</th>
                        <th scope="col">address</th>
                        <th scope="col">country</th>
                        <th scope="col">city</th>
                        <th scope="col">phone</th>
                        <th scope="col">time</th>
                        <th scope="col">product name</th>
                        <th scope="col">qty</th>
                        <th scope="col">totalprice</th>
                        <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <th scope="row">
                            <?php echo e($index+1); ?>

                        </th>

                        <td><?php echo e($order[0]['id']); ?></td>
                        <td><?php echo e($order[0]['name']); ?></td>
                        <td><?php echo e($order[0]['address']); ?></td>
                        <td><?php echo e($order[0]['country']); ?></td>
                        <td><?php echo e($order[0]['city']); ?></td>
                        <td><?php echo e($order[0]['phone']); ?></td>
                        <td><?php echo e($order[0]['time']); ?> , <?php echo e($order[0]['user_id']); ?></td>

                        <td>
                            <?php $__currentLoopData = $order[1]->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($item['name']); ?>,
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>

                        <td><?php echo e($order[1]->totalqty); ?></td>
                        <td><?php echo e($order[1]->totalprice); ?></td>
                        <form action="<?php echo e(route('admin.store',$ord[$index]['id'])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <td>
                                <input type="checkbox" name="status" value="1">
                                <?php if( ( $ord[$index]['status'] ) == 0): ?>
                                <p style="color: #09b509;"> Active </p>
                                <?php else: ?>
                                <p style="color: #2266ff;"> Deliverd </p>
                                <?php endif; ?>
                            </td>

                            <td> <button type="submit" class="btn btn-success">Update</button>
                            </td>
                        </form>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nbeauty\resources\views/admin/admin.blade.php ENDPATH**/ ?>